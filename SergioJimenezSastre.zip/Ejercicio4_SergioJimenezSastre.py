#----- EJERCICIO 4. SERGIO JIM�NEZ SASTRE -----

cajero_billetes=[[500,10],[200,0],[100,0],[50,30],[20,0],[10,20],[5,25]]

cantidad=input('�Qu� cantidad de Euros desea?: ')

for i in cajero_billetes:
    
