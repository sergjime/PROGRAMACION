#----- EJERCICIO 1. SERGIO JIM�NEZ SASTRE -----
def obtenir_binari(num):
    resultado = '';
    while num / 2 >= 1:
      resultado = str(num % 2) + resultado
      num = num /2
    resultado = str(num) + resultado
    return resultado
num=input('Introduce un valor decimal (base 10): ')
binario=obtenir_binari(num)
print binario







