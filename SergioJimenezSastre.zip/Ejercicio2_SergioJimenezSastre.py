#----- EJERCICIO 2. SERGIO JIM�NEZ SASTRE -----
def convertir_en_base(num,base):
    resultado = ''
    tempdiv = ''
    while num / base >= 1:
        if base > 10:
            if num % base == 10:
                tempdiv = 'A'
            else:
                if num % base == 11:
                    tempdiv = 'B'
                else:
                    if num % base == 12:
                        tempdiv = 'C'
                    else:
                        if num % base == 13:
                            tempdiv = 'D'
                        else:
                            if num % base == 14:
                                tempdiv = 'E'
                            else:
                                if num % base == 15:
                                    tempdiv = 'F'
        else:
            tempdiv = str(num % base)
        resultat = tempdiv + resultat
        num = num / base
    if base > 10:
        if num % base == 10:
            tempdiv = 'A'
        else:
            if num % base == 11:
                tempdiv = 'B'
            else:
                if num % base == 12:
                    tempdiv = 'C'
                else:
                    if num % base == 13:
                        tempdiv = 'D'
                    else:
                        if num % base == 14:
                            tempdiv = 'E'
                        else:
                            if num % base == 15:
                                tempdiv = 'F'
    else:
        tempdiv = str(num % base)
    resultado = tempdiv  + resultado
    return resultado

num=input('Introduce un valor: ')
base=input('Introduce en qu� base lo quieres: ')
num_base=convertir_en_base(num,base)
print num_base







