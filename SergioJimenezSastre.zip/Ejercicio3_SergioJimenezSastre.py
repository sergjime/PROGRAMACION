#----- EJERCICIO 3. SERGIO JIM�NEZ SASTRE -----
import time
from datetime import datetime

def menu():
    print "==================================="
    print "= Lista de espera Programaci�n     "
    print "==================================="
    print "= 1) Poner en espera               "
    print "= 2) Alumnos atendidos             "
    print "= 3) Mostrar la lista de espera    "
    print "= 4) Salir                         "
    print "==================================="

def restar_hora(hora1,hora2):
    formato="%H:%M:%S"
    h1=datetime.strptime(hora1,formato)
    h2=datetime.strptime(hora2,formato)
    resultado=h1-h2
    return str(resultado)

def EnEspera(alumnos):
    fecha=0
    contador=0
    nombre=raw_input('Introduce el nombre del alumno: ')
    for i in range(len(alumnos)):
        if alumnos[i][0]==nombre:
            contador=contador+1
    if contador==0:
        descripcion=raw_input('Introduce el apellido del alumno: ')
        hora=time.strftime("%X")
        alumnos.extend([[nombre, descripcion, hora]])
        print '_____________________________________________________'
    
def AlumnosAtendidos(alumnos):
    posicion=0
    contador=0
    num=input('Dame el n�mero de la lista que te identifica:')
    for i in range(len(alumnos)):
        if alumnos[i][0]==num:
            contador=contador+1
            posicion=i
    if contador<>0:
        del alumnos[posicion]
    print '=================================='
    print 'Has sido eliminado de la lista    '
    print 'Nombre:',alumnos[num][0]
    print 'Apellidos:',alumnos[num][1]
    hora=time.strftime("%X")
    tiempo=restar_hora(hora,alumnos[num][2])
    print 'Tiempo de espera:',tiempo
    print '_____________________________________________________'
    
def MostrarLista(alumnos):
    print '=================================='
    print '= Lista de espera IES FBMOLL =    ' 
    print '=================================='
    for i in range(len(alumnos)):
        print 'N�',i+1,' Nombre:',alumnos[i][0],' Apelllidos:',alumnos[i][1],' En espera:',alumnos[i][2]
    print '_____________________________________________________'
    
alumnos=[]
opcion=0
while opcion<>6:
    menu ()
    opcion=input('Selecciona la opci�n que desea:')
    if opcion==1:
        EnEspera(alumnos)
    elif opcion==2:
        AlumnosAtendidos(alumnos)
    elif opcion==3:
        MostrarLista(alumnos)
