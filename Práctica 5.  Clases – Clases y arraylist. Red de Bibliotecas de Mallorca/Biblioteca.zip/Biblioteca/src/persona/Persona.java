package persona;

public class Persona {
        
//ATRIBUTOS
    
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String dni;
    private String cargo;
}
